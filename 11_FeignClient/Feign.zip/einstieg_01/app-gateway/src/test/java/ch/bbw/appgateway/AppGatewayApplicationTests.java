package ch.bbw.appgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
