package ch.bbw.service01;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient("service-02")
public interface BooksClient {
    @GetMapping("books")
    List<Book> getBooks();
}

