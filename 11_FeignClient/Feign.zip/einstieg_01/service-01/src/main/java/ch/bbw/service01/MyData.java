package ch.bbw.service01;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MyData {
    private String name;
}
