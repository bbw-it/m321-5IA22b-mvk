package ch.bbw.service02;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class RESTBookController {
    private List<Book> books;

    public RESTBookController() {
        books = new ArrayList<>();
        books.add(new Book(1, "The Metamorphosis", "Franz Kafka"));
        books.add(new Book(2, "The Trial", "Franz Kafka"));
        books.add(new Book(3, "1984", "George Orwell"));
        books.add(new Book(4, "Animal Farm", "George Orwell"));
    }

    @GetMapping("books")
    public List<Book> getBooks() {
        return books;
    }

    @PostMapping("books")
    public Book addBook(@RequestBody Book book) {
        int lastId = books.stream()
                .mapToInt(Book::getId)
                .max()
                .orElse(1);
        book.setId(lastId + 1);
        books.add(book);
        return book;
    }
}