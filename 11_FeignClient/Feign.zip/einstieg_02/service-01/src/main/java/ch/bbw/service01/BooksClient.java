package ch.bbw.service01;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

@FeignClient("service-02")
public interface BooksClient {
    @GetMapping("books")
    List<Book> getBooks();

    @PostMapping
    Book addBook(@RequestBody Book book);
}
