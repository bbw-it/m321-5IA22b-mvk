package ch.bbw.service02;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MainController {

    @Autowired
    private DiscoveryClient discoveryClient;

    public void displayDiscoveryClientData() {
        System.out.println("--------------------------------------");
        List<ServiceInstance> serviceInstanceList = discoveryClient.getInstances("service-01");
        System.out.println("Nr. of Entries: " + serviceInstanceList.size());
        System.out.println("Description: " + discoveryClient.description());
        /*serviceInstanceList.forEach(si -> {
            System.out.println("Uri: " + si.getUri().toString());
        });*/
        List<String> services = discoveryClient.getServices();
        System.out.println(String.format("Services: (%d)", services.size()));
        services.forEach(System.out::println);

        System.out.println("--------------------------------------");
    }

    @GetMapping("api")
    public MyData getData() {
        displayDiscoveryClientData();

        return new MyData("Hello World from Service 02");
    }

}
