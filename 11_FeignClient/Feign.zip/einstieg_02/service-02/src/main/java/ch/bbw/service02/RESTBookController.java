package ch.bbw.service02;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class RESTBookController {

    private List<Book> books;

    public RESTBookController() {
        books = new ArrayList<>();
        books.add(new Book(1, "The Metamorphosis", "Franz Kafka"));
        books.add(new Book(2, "The Trial", "Franz Kafka"));
        books.add(new Book(3, "1984", "George Orwell"));
        books.add(new Book(4, "Animal Farm", "George Orwell"));
    }

    @GetMapping("books")
    public List<Book> getBooks() {
        return books;
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        book.setId(books.stream()
                .map(b -> b.getId())
                .max(Integer::compareTo)
                .orElse(books.size()) + 1);
        books.add(book);
        return book;
    }
}
