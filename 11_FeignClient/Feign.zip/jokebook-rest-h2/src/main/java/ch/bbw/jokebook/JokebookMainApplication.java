package ch.bbw.jokebook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JokebookMainApplication {

    public static void main(String[] args) {
        SpringApplication.run(JokebookMainApplication.class, args);
    }

}
