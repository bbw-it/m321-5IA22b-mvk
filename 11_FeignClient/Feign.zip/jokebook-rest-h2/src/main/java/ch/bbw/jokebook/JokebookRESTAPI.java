package ch.bbw.jokebook;

import ch.bbw.jokebook.model.Joke;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api")
public class JokebookRESTAPI {

    private JokeRepository repository;

    @Autowired // Dependency injection
    public JokebookRESTAPI(JokeRepository repository) {
        this.repository = repository;
    }

    @GetMapping("hello")
    public String hello() {
        return "hello";
    }

    @GetMapping("jokes")
    public List<Joke> getJokes() {
        return (List<Joke>) repository.findAll();
    }

    @GetMapping("jokes/{id}")
    public ResponseEntity<Joke> getJoke(@PathVariable long id) {
        Joke joke = repository
                .findById(id)
                .orElse(null);
        return joke != null
                ? ResponseEntity.ok(joke)
                : ResponseEntity.notFound().build(); // 404
    }

    @DeleteMapping("jokes/{id}")
    public ResponseEntity<?> deleteJoke(@PathVariable long id) {
        repository.deleteById(id);
        return ResponseEntity.status(204).build();
    }

    @PostMapping("jokes")
    public ResponseEntity<Joke> createJoke(@RequestBody Joke joke) {
        Joke newJoke = repository.save(joke);
        return ResponseEntity.ok(newJoke); // todo: 201
    }

    @PutMapping("jokes/{id}")
    public ResponseEntity<?> updateJoke(@PathVariable long id, @RequestBody Joke joke) {
        joke.setId(id);
        Joke updatedJoke = repository.save(joke);
        return ResponseEntity.ok(updatedJoke);
    }


}
