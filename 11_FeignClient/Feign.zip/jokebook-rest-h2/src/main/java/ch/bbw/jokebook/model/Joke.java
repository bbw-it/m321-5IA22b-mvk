package ch.bbw.jokebook.model;

import lombok.Data;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Data
@Entity
public class Joke {
	
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	private String text;
	private int rating;
	@Temporal(TemporalType.TIMESTAMP)
	private Date date;
	
}
