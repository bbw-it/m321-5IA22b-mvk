DROP TABLE IF EXISTS joke;
CREATE TABLE IF NOT EXISTS joke (
    id int AUTO_INCREMENT PRIMARY KEY,
    `text` VARCHAR(250) NOT NULL,
    rating int NOT NULL,
    date datetime NOT NULL
);

INSERT INTO `joke` (`id`, `text`, `rating`, `date`) VALUES
(1, 'Kunde: "Ich möchte Ihren Chef sprechen!"\r\nSekretärin: "Geht leider nicht, er ist nicht da!"\r\nKunde: "Ich hab ihn doch durchs Fenster gesehen!"\r\nSekretärin: "Er Sie auch!"', 5, '2014-01-08 21:39:40'),
(2, 'Der Verwaltungsrat zum CEO:\r\n"Na, wie macht sich denn der neue Buchhalter?"\r\nCEO: "Toll, dieser Mann!"\r\nVerwaltungsrat: "Was kann er denn so besonderes?"\r\nCEO: "Er ist gelernter Friseur, er kann frisieren!"', 3, '2014-01-08 21:42:41'),
(3, 'Chef: "Müller, Sie sind das beste Pferd in meinem Stall!"\r\nMüller: "Wirklich, Chef?"\r\nChef: "Ja, Sie machen den meisten Mist!"', 5, '2014-01-08 21:43:20');
