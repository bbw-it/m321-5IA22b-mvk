package ch.bbw.service01;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@CrossOrigin("*")
public class MainController {

    @Autowired
    private BooksClient booksClient;

    @GetMapping("api")
    public MyData getData() {
        return new MyData("Hello World from Service 01");
    }

    @GetMapping("api/books")
    public List<String> getBooks() {
        return booksClient.getBooks().stream()
                .map(book -> String.format("%s (%s)",book.getTitle(),book.getAuthor()))
                .toList();
    }

}
