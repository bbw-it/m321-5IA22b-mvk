package ch.bbw.service02;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MyData {
    private String name;
}
